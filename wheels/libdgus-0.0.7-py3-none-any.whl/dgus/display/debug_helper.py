def print_bytes_as_hex(data : bytes):
    print([hex(x) for x in data])
    